window.onload=function(){
  let initialbuses=[];

  if(localStorage.getItem("buses")==null){
    localStorage.setItem("buses",JSON.stringify(initialbuses));
                                                                                                                
  }
};

function display(bus_data=undefined) {
  let samplearray="";
  let buses;
  if(bus_data==undefined){
  buses= JSON.parse(localStorage.getItem("buses"));
  }
  else{
  buses = bus_data;
  }
 

  buses.forEach(function(element,index) {
    let presetrow=`
    <tr>
 <td>${index+1}</td>
 <td>${element.name}</td>
 <td>${element.source}</td>
 <td>${element.destination}</td>
 <td>${element.number}</td>
 <td>${element.passengerCapacity}</td>
 <td><button onclick="deleteElement(${index})" class="del_btn">delete</button>
 </td>
 </tr>`;
 samplearray += presetrow;
    
  });
  console.log(typeof(buses));
  document.getElementById("tablerows").innerHTML=samplearray;
}
function addBus(e) {
  e.preventDefault()
  let bus = {};
 let upname = document.getElementById("upname").value;
 let upsource = document.getElementById("upsource").value;
 let updestination = document.getElementById("updestination").value;
 let upbusno = document.getElementById("upbusno").value;
 let uppasscap = document.getElementById("uppasscap").value;

 bus.name = upname;
 bus.source=upsource;
 bus.destination=updestination;
 bus.number=upbusno;
 bus.passengerCapacity=uppasscap;

 let element=JSON.parse(localStorage.getItem("element"));
 element.push(bus);
//  strrtbuses=JSON.stringify(retbus);
 localStorage.setItem("buses",JSON.stringify(buses));

//  let retbus1 = JSON.parse(localStorage.getItem("buses"));
//  display(retbus1);

//  return false;
// }
display();


}