let empo = [
    {
      name: "Riddhi",
      age: 22,
      city: "Vasco",
      salary: "70000",
    },
    {
      name: "Rati",
      age: 34,
      city: "Margao",
     salary: "50000",
    },
    {
      name: "Siddhant",
      age: 30,
      city: "Mapusa",
     salary: "600000",
    },
    {
        name: "Shamira",
        age: 25,
        city: "New Delhi",
        salary: "750000",
      },
      {
        name: "Sushant",
        age: 33,
        city: "Manali",
        salary: "80000",
      },
  ];
  
  function display(superarray) {
    let tabledata = "";
  
    superarray.forEach(function (employee, index) {
      let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${employee.name}</td>
      <td>${employee.age}</td>
      <td>${employee.city}</td>
      <td>${employee.salary}</td>
      <td>
      <button onclick='deleteEmployee(${index})'>delete</button>
      <button onclick='showModal(${index})'>update</button>
      </td>
      </tr>`;
  
      tabledata += currentrow;
    });
  
    // document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
      document.getElementById("tdata").innerHTML = tabledata;
  }
  
  display(empo);
  
  function addEmployee(e) {
    e.preventDefault();
    let employee = {};
    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let city = document.getElementById("city").value;
    let salary = document.getElementById("salary").value;
    employee.name = name;
    employee.age = Number(age);
    employee.city = city;
    employee.salary = salary;
  
    empo.push(employee);
  
    display(empo);
  
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("city").value = "";
    document.getElementById("salary").value = "";
  }
  
  function searchByName() {
    let searchValue = document.getElementById("searchName").value;
  
    let newdata = empo.filter(function (employee) {
      return (
        employee.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }

  function searchByCity() {
    let searchValue = document.getElementById("searchCity").value;
  
    let newdata = empo.filter(function (employee) {
      return (
        employee.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }
  
  function deleteEmployee(index) {
    empo.splice(index, 1);
    display(empo);
  }
  
  let updateIndex;
  
  function copyEmployee(index) {
    updateIndex = index;
    let employee = empo[index];
  
    document.getElementById("upname").value = employee.name;
    document.getElementById("upage").value = employee.age;
    document.getElementById("upcity").value = employee.city;
    document.getElementById("upsalary").value = employee.salary;
  }
  
  function updateEmployee(e) {
    e.preventDefault();
    let employee = empo[updateIndex];
    console.log(employee);
    let name = document.getElementById("upname").value;
    let age = document.getElementById("upage").value;
    let city = document.getElementById("upcity").value;
    let salary = document.getElementById("upsalary").value;
    employee.name = name;
    employee.age = Number(age);
    employee.city = city;
    employee.salary = salary;
    console.log(employee);
  
    display(empo);
  
    // code for hiding from anywhere
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none";
  }
  
  function showModal(index) {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "block";
  
    copyEmployee(index);
  }
  
  function hideModal(event) {
    if (event.target.className == "modal") {
      let modal = document.getElementsByClassName("modal")[0];
      modal.style.display = "none";
    }
  }