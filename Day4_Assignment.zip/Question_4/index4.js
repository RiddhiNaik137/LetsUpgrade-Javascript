let  bio =[
    {
    name:"riddhi",
    age:22,
    country:"India",
    hobbies:['drawing','writting']
},
{
    name:"rati",
    age:18,
    country:"India",
    hobbies:['drawing','craft']
},
{
    name:"siddy",
    age:35,
    country:"UK",
    hobbies:['dancing','singing','racing','reading']
},
{
    name:"leenon",
    age:24,
    country:"paris",
    hobbies:['dancing','singing','acting']
}
];
function displayage(bio){
    console.log("people with age less then 30!")
    bio.forEach(element => {
        if(element.age<30)
        {
            console.log(element);
        }
    });
}
    function displaycountry(bio){
        console.log(" objects having country India!")
        bio.forEach(element =>{
            if (element.country=="India") {
                console.log(element);
            }
                 
        });
    }
    displayage(bio);
    displaycountry(bio);