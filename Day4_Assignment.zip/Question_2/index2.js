function copy(){
    var n1 = document.getElementById("n1");
    var n2 = document.getElementById("n2");
    n2.value=n1.value;
}