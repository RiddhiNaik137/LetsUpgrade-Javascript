function changeImage()
{
    const ele =document.getElementById('image1');
 const newUrl="https://www.bloomnation.com/blog/wp-content/uploads/2012/07/Rainbow-Rose.jpg";
 ele.src =newUrl;
}
function changeImage2()
{
    const ele =document.getElementById('image1');
 const newUrl="https://cdn.pixabay.com/photo/2015/04/19/08/33/flower-729512__340.jpg";
 ele.src =newUrl;
}
function changeImage3()
{
    const ele =document.getElementById('image1');
 const newUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQrp3stFcW_KV8sYWtD6ggYu49Gc0j8jkOm4w&usqp=CAU";
 ele.src =newUrl;
}