let product = [
    {
      id: 1,
      name: "Golden Blue Lhenga",
      size: "m",
      color: "Blue",
      price: 8000,
      image: "https://rb.gy/5v6ioh",
      description: "Traditional Wear Lhenga",
    },
    {
      id: 2,
      name: "Golden Red Lhenga",
      size: "M",
      color: "Red",
      price: 6000,
      image: "https://rb.gy/hv2zqc",
      description: "Wedding Wear",
    },
  
    {
      id: 3,
  
      name: "Silky Gown",
      size: "l",
      color: "Royal Blue",
      price: 19000,
      image: "https://rb.gy/ivqbft",
      description: "Shiny Long Gown",
    },
  
    {
      id: 4,
      name: "Ball Gown",
      size: "L",
      color: "Gilitter Blue",
      price: 1300,
      image: "https://rb.gy/b7i06k",
      description: "Off Shoulder Gown",
    },
  
    {
      id: 5,
      name: "Red Top",
      size: "S",
      color: "Red",
      price: 8000,
      image:"https://rb.gy/r39oji",
      description: "Formal Wear",
    },
  
    {
      id: 6,
      name: "Top",
      size: "M",
      color: "Faded Blue",
      price: 800,
      image: "https://rb.gy/stgbah",
      description: "Blue Top with patterns",
    },
    {
      id: 7,
      name: "Saree",
      size: "M",
      color: "Red",
      price: 7000,
      image: "https://rb.gy/pbk1zv",
      description: "Netted Party Wear Saree ",
    },
    {
      id: 8,
      name: "Embroided Saree",
      size: "L",
      color: "Light Grey",
      price: 10000,
      image:"https://rb.gy/fp1cz3",
      description: "Pink Border saree",
    },
    {
      id: 9,
      name: "Kurta",
      size: "-",
      color: "grey",
      price: 1200,
      image: "https://rb.gy/vi5sbm",
      description: "Long Kurta",
    },
    {
      id: 10,
      name: "Round Kurta",
      size: "M",
      color: "Aqua Blue",
      price: 4000,
      image: "https://rb.gy/oyoiar",
      description: "Dress Like Kurta with Shawl",
    },
    {
        id: 11,
        name: "Kurta",
        size: "M",
        color: "Black",
        price: 4000,
        image: "https://rb.gy/jqgvtm",
        description: "Kurta and coatty",
      },
    
  ];
   let cart=[];
   let count=0;
  function displayproduct(merchd, type="main", place="card") {
      console.log(merchd);
      let strproduct = "";
      let arrproduct="";
      merchd.forEach(function (ele, index) {
          if(type=="main"){
              strproduct = ` <div class="productcardbg">
          <div class="image">
            <img src="${ele.image}" width="100%" />
          </div>
          <div>
          <h3 style="font-family : Geneva, Verdana, sans-serif; padding-left : 10px">${ele.name}</h3>
          <p>Size : ${ele.size}</p>
          <p>Color : ${ele.color}</p>
          <p>price : ${ele.price}</p>
          <h5 style="font-family : Geneva, Verdana, sans-serif; padding-left : 10px ;padding-top : 10px">${ele.description}</h5>
          <p style="padding-top: 5px">
            <button class="buttonbg" onclick="addToCart(${ele.id})">Add to Cart</button>
          </p>
        </div>
        </div>`;
        arrproduct+=strproduct;
          }
          
      if(type=="cartd"){
                  strproduct = ` <div class="productcardbg">
          <div class="image">
            <img src="/images/${ele.image}" width="100%" />
          </div>
          <div>
          <h3 style="font-family : Geneva, Verdana, sans-serif; padding-left : 10px">${ele.name}</h3>
          <p>Size : ${ele.size}</p>
          <p>Color : ${ele.color}</p>
          <p>price : ${ele.price}</p>
          <h5 style="font-family : Geneva, Verdana, sans-serif; padding-left : 10px ;padding-top : 10px">${ele.description}</h5>
          <p style="padding-top: 5px">
            <button class="buttonbg" onclick="deleteproduct(${ele.id})">Delete item</button>
          </p>
        </div>
        </div>`;
              
          arrproduct += strproduct;    
  
          }
      });
      
  document.getElementById(place).innerHTML = arrproduct;
      
  }
  
  
  function getProductByID(mercha, id) {
    return mercha.find(function (ele) {
      return ele.id == id;
    });
  }
  let flag=false;
  function addToCart(id) {
  flag=false;
    let item = getProductByID(product, id);
  
    cart.forEach(function(element){
        if(element.id==item.id){
            flag=true;
            
        }
        
  
    })
    if (flag) {
        alert("dont add the same product twice");
      return 0;
    }
    cart.push(item);
    count+=1;
    document.getElementById("numb").innerText=count;
    let type="cartd";
    let place="cartcard";
    displayproduct(cart, type, place);
  
  }
  
  
  function search(){
      console.log("calling");
  }
  function deleteproduct(id){
    let item = getProductByID(product, id);
    let index = cart.findIndex(function (item1) {
      return item1.id == id;
    });
    cart.splice(index, 1);
    count-=1;
     document.getElementById("numb").innerText = count;
     let type = "cartd";
     let place = "cartcard";
     displayproduct(cart, type, place);
  }
  
  function filter(){
      let minv=document.getElementById("minp").value;
      let maxv = document.getElementById("maxp").value;
      let items=product.filter(function(itemsl){
          return itemsl.price>=minv && itemsl.price<=maxv;
      })
       displayproduct(items);
      document.getElementById("minp").value="";
        document.getElementById("maxp").value="";
  }
  
  function search(){
      let str= document.getElementById("serstr").value;
      console.log(str);
      let items = product.filter(function(ele) {
        return ele.name.indexOf(str)!=-1;
      });
      displayproduct(items);
  
  
  }
  displayproduct(product);