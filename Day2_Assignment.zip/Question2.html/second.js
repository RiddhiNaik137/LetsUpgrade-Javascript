var secs = 2;
var mints=(secs/60);
var string=secs + " seconds is "+ mints + " minutes. ";
console.log(string);