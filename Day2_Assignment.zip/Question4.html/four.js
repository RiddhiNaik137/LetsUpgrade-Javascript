let arr = ["Meenu","Megha","siddy","Gopal","Rahul"];
for(let i=0;i<arr.length;i++)
{
    if(arr[i].includes("a"))
    {
    console.log(arr[i]);
    }
  
}


