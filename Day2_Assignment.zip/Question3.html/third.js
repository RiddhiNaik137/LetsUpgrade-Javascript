let data = ["Meena","Megha","Rati","Gopal","Rahul"];
console.log(data[2]);