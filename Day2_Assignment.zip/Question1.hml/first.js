let str = "Javascript is coolest language! "; 
let n=str.indexOf("g");
console.log(n);