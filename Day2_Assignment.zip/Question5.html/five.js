let arr = [1,2,3,4,5,6,7].reverse();
console.log(arr);
var a = ["Meenu","Megha","siddy","Gopal","Rahul"];
console.log (a.reverse());